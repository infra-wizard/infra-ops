# Quick Start Guide

This guide will help you get the Thingworx ExternalSecrets chart up and running in 5 minutes.

## Prerequisites

- Kubernetes cluster with `kubectl` configured
- External Secrets Operator installed
- Azure Key Vault with secrets
- Azure permissions configured (Managed Identity or Service Principal)

## Step 1: Install External Secrets Operator

```bash
helm repo add external-secrets https://charts.external-secrets.io
helm install external-secrets \
  external-secrets/external-secrets \
  -n external-secrets-system \
  --create-namespace
```

Wait for the operator to be ready:

```bash
kubectl wait --for=condition=available --timeout=300s \
  deployment/external-secrets -n external-secrets-system
```

## Step 2: Create Target Namespaces

```bash
kubectl create namespace argo-cd --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace twx --dry-run=client -o yaml | kubectl apply -f -
```

## Step 3: Create SecretStore or ClusterSecretStore

### Option A: ClusterSecretStore (Recommended)

Edit and apply:

```bash
cat <<EOF | kubectl apply -f -
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: azure-store
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://YOUR-KEYVAULT-NAME.vault.azure.net"
EOF
```

Update values.yaml:

```yaml
secretStore:
  kind: ClusterSecretStore
  name: azure-store
```

### Option B: Per-Namespace SecretStore

```bash
# For argo-cd namespace
cat <<EOF | kubectl apply -f -
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: azure-store
  namespace: argo-cd
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://YOUR-KEYVAULT-NAME.vault.azure.net"
EOF

# For twx namespace
cat <<EOF | kubectl apply -f -
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: azure-store
  namespace: twx
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://YOUR-KEYVAULT-NAME.vault.azure.net"
EOF
```

## Step 4: Verify SecretStore

```bash
# For ClusterSecretStore
kubectl get clustersecretstore

# For SecretStore
kubectl get secretstore -n argo-cd
kubectl get secretstore -n twx
```

## Step 5: Install the Helm Chart

```bash
helm install thingworx-secrets ./thingworx-external-secrets
```

## Step 6: Verify ExternalSecrets

```bash
# Check ExternalSecret resources
kubectl get externalsecrets -n argo-cd
kubectl get externalsecrets -n twx

# Check if secrets are synced
kubectl get externalsecret thingworx-secrets -n argo-cd -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}'
# Should output: True

kubectl get externalsecret thingworx-secrets -n twx -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}'
# Should output: True
```

## Step 7: Verify Created Secrets

```bash
# Check secrets were created
kubectl get secret thingworx-secrets -n argo-cd
kubectl get secret thingworx-secrets -n twx

# List secret keys
kubectl get secret thingworx-secrets -n twx -o jsonpath='{.data}' | jq 'keys'
```

## Troubleshooting

### ExternalSecret Not Ready

```bash
# Check ExternalSecret status
kubectl describe externalsecret thingworx-secrets -n twx

# Check External Secrets Operator logs
kubectl logs -n external-secrets-system deployment/external-secrets
```

### Common Issues

1. **SecretStore not found**
   - Verify SecretStore exists: `kubectl get secretstore -n twx`
   - For ClusterSecretStore: `kubectl get clustersecretstore`

2. **Key Vault access denied**
   - Check Azure permissions
   - Verify Managed Identity has Key Vault Secrets User role

3. **Secret not in Key Vault**
   - List secrets: `az keyvault secret list --vault-name YOUR-KEYVAULT-NAME`
   - Verify secret names match exactly (case-sensitive)

## Next Steps

- Read the full [README.md](../README.md) for advanced configuration
- Check [example values files](.) for different scenarios
- Review [secretstore examples](.) for authentication options

## Quick Commands Reference

```bash
# Force refresh secrets
kubectl annotate externalsecret thingworx-secrets -n twx force-sync="$(date +%s)" --overwrite

# View secret value (decoded)
kubectl get secret thingworx-secrets -n twx -o jsonpath='{.data.AKS-NS}' | base64 -d

# Delete and recreate
helm uninstall thingworx-secrets
helm install thingworx-secrets ./thingworx-external-secrets

# Upgrade chart
helm upgrade thingworx-secrets ./thingworx-external-secrets -f custom-values.yaml
```
