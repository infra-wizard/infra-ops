# Thingworx ExternalSecrets Helm Chart

A Helm chart for managing Thingworx secrets across multiple namespaces using the [External Secrets Operator](https://external-secrets.io/).

## Overview

This chart creates ExternalSecret resources that synchronize secrets from Azure Key Vault to Kubernetes secrets across multiple namespaces. It's designed specifically for Thingworx deployments that need secrets in both ArgoCD and Thingworx namespaces.

## Prerequisites

### 1. External Secrets Operator

The External Secrets Operator must be installed in your cluster:

```bash
helm repo add external-secrets https://charts.external-secrets.io
helm repo update

helm install external-secrets \
  external-secrets/external-secrets \
  -n external-secrets-system \
  --create-namespace
```

Verify installation:

```bash
kubectl get pods -n external-secrets-system
```

### 2. SecretStore Configuration

A SecretStore (or ClusterSecretStore) named `azure-store` must exist in each target namespace.

#### Option A: Create SecretStore per Namespace

Create a SecretStore in each namespace:

```yaml
# secretstore-argo-cd.yaml
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: azure-store
  namespace: argo-cd
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://<your-keyvault-name>.vault.azure.net"
      # Or use Service Principal:
      # authType: ServicePrincipal
      # tenantId: "<tenant-id>"
      # authSecretRef:
      #   clientId:
      #     name: azure-secret
      #     key: client-id
      #   clientSecret:
      #     name: azure-secret
      #     key: client-secret
---
# secretstore-twx.yaml
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: azure-store
  namespace: twx
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://<your-keyvault-name>.vault.azure.net"
```

Apply the SecretStores:

```bash
kubectl apply -f secretstore-argo-cd.yaml
kubectl apply -f secretstore-twx.yaml
```

#### Option B: Use ClusterSecretStore (Recommended)

Create a single ClusterSecretStore accessible from all namespaces:

```yaml
# clustersecretstore.yaml
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: azure-store
spec:
  provider:
    azurekv:
      authType: ManagedIdentity
      vaultUrl: "https://<your-keyvault-name>.vault.azure.net"
```

Apply:

```bash
kubectl apply -f clustersecretstore.yaml
```

Then update `values.yaml`:

```yaml
secretStore:
  kind: ClusterSecretStore  # Changed from SecretStore
  name: azure-store
```

### 3. Azure Permissions

Ensure the Azure Managed Identity or Service Principal has the following permissions:

- **Key Vault**: `Key Vault Secrets User` role
- **Secrets**: `Get` and `List` permissions

Grant permissions:

```bash
# For Managed Identity
az keyvault set-policy \
  --name <keyvault-name> \
  --object-id <managed-identity-object-id> \
  --secret-permissions get list

# For Service Principal
az keyvault set-policy \
  --name <keyvault-name> \
  --spn <service-principal-id> \
  --secret-permissions get list
```

### 4. Namespace Creation

Ensure target namespaces exist:

```bash
kubectl create namespace argo-cd --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace twx --dry-run=client -o yaml | kubectl apply -f -
```

## Installation

### Basic Installation

Install with default configuration (creates secrets in argo-cd and twx namespaces):

```bash
helm install thingworx-secrets ./thingworx-external-secrets
```

### Installation with Custom Values

Create a custom values file:

```yaml
# custom-values.yaml
namespaces:
  - name: argo-cd
  - name: twx
  - name: production-twx

secretStore:
  kind: ClusterSecretStore
  name: azure-cluster-store

externalSecret:
  name: thingworx-secrets
  refreshInterval: 30m
```

Install:

```bash
helm install thingworx-secrets ./thingworx-external-secrets \
  -f custom-values.yaml
```

### Installation in Specific Namespace

While the ExternalSecret resources are created in target namespaces, the Helm release itself is tracked in a namespace:

```bash
helm install thingworx-secrets ./thingworx-external-secrets \
  --namespace external-secrets-system
```

## Configuration

### values.yaml Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `namespaces` | List of namespaces where ExternalSecrets will be created | `[{name: argo-cd}, {name: twx}]` |
| `externalSecret.name` | Name of the ExternalSecret resource | `thingworx-secrets` |
| `externalSecret.targetSecretName` | Name of the Kubernetes Secret to create | `thingworx-secrets` |
| `externalSecret.refreshInterval` | How often to sync secrets | `1h` |
| `externalSecret.creationPolicy` | Secret creation policy | `Owner` |
| `externalSecret.labels` | Labels for ExternalSecret resource | `{}` |
| `externalSecret.annotations` | Annotations for ExternalSecret resource | `{}` |
| `externalSecret.template` | Template for the target Secret | `{}` |
| `externalSecret.data` | List of secrets to fetch | See values.yaml |
| `secretStore.kind` | Type of SecretStore | `SecretStore` |
| `secretStore.name` | Name of the SecretStore | `azure-store` |

### Adding/Removing Secrets

To add new secrets, edit `values.yaml`:

```yaml
externalSecret:
  data:
    # ... existing secrets ...
    - secretKey: NEW-SECRET-KEY
      remoteRef:
        key: NEW-SECRET-KEY
        # Optional: specific property in a JSON secret
        # property: nestedKey
```

To remove secrets, simply delete the entry from the `data` list.

### Configuring Different Namespaces

To deploy to different namespaces:

```yaml
namespaces:
  - name: production
  - name: staging
  - name: development
```

### Using with ArgoCD

Add sync wave annotation for proper ordering:

```yaml
externalSecret:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"  # Create secrets before other resources
```

## Usage Examples

### Example 1: Basic Multi-Namespace Deployment

```yaml
# values.yaml
namespaces:
  - name: argo-cd
  - name: twx

secretStore:
  kind: SecretStore
  name: azure-store
```

### Example 2: Using ClusterSecretStore

```yaml
# values.yaml
namespaces:
  - name: argo-cd
  - name: twx

secretStore:
  kind: ClusterSecretStore
  name: azure-cluster-store
```

### Example 3: Custom Secret Template

```yaml
# values.yaml
externalSecret:
  template:
    type: Opaque
    metadata:
      labels:
        app: thingworx
        managed-by: external-secrets
    data:
      # Transform secrets during creation
      DATABASE_URL: "postgresql://{{ .TWX_DATABASE_USERNAME }}:{{ .TWX_DATABASE_PASSWORD }}@{{ .DATABASE_HOST }}:{{ .DATABASE_PORT }}/thingworx"
```

### Example 4: Different Refresh Intervals

```yaml
# values.yaml
externalSecret:
  refreshInterval: 15m  # Refresh every 15 minutes
```

### Example 5: Using Secret Properties

For JSON secrets in Key Vault:

```yaml
externalSecret:
  data:
    - secretKey: database-config
      remoteRef:
        key: database-config-json
        property: connectionString  # Extract specific property
```

## Verification

### Check ExternalSecret Resources

```bash
# Check ExternalSecret in argo-cd namespace
kubectl get externalsecrets -n argo-cd

# Check ExternalSecret in twx namespace
kubectl get externalsecrets -n twx

# View ExternalSecret details
kubectl describe externalsecret thingworx-secrets -n argo-cd
```

### Check Created Secrets

```bash
# Check secret in argo-cd namespace
kubectl get secret thingworx-secrets -n argo-cd

# Check secret in twx namespace
kubectl get secret thingworx-secrets -n twx

# View secret keys (not values)
kubectl get secret thingworx-secrets -n twx -o jsonpath='{.data}' | jq 'keys'
```

### Check Secret Sync Status

```bash
# Check sync status
kubectl get externalsecret thingworx-secrets -n twx -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}'

# Should output: True
```

### View Secret Data

```bash
# Decode a specific secret value
kubectl get secret thingworx-secrets -n twx -o jsonpath='{.data.AKS-NS}' | base64 -d

# View all secret keys
kubectl get secret thingworx-secrets -n twx -o json | jq '.data | keys'
```

## Troubleshooting

### ExternalSecret Not Syncing

**Check ExternalSecret status:**

```bash
kubectl describe externalsecret thingworx-secrets -n twx
```

**Common issues:**

1. **SecretStore not found**
   ```
   Error: SecretStore.external-secrets.io "azure-store" not found
   ```
   Solution: Create the SecretStore in the namespace or use ClusterSecretStore

2. **Key Vault access denied**
   ```
   Error: azure keyvault get secret: failed to get secret
   ```
   Solution: Grant proper permissions to the Managed Identity or Service Principal

3. **Secret key not found in Key Vault**
   ```
   Error: secret "SECRET-NAME" not found in key vault
   ```
   Solution: Verify the secret exists in Azure Key Vault with the exact name

### Secret Not Created

Check External Secrets Operator logs:

```bash
kubectl logs -n external-secrets-system deployment/external-secrets
```

### Refresh Not Working

Force refresh by deleting and recreating the ExternalSecret:

```bash
kubectl delete externalsecret thingworx-secrets -n twx
helm upgrade thingworx-secrets ./thingworx-external-secrets
```

Or annotate the ExternalSecret to force refresh:

```bash
kubectl annotate externalsecret thingworx-secrets -n twx force-sync="$(date +%s)" --overwrite
```

## Upgrading

### Upgrade with New Secrets

Add new secrets to `values.yaml` and upgrade:

```bash
helm upgrade thingworx-secrets ./thingworx-external-secrets \
  -f values.yaml
```

### Upgrade to Different Namespaces

Modify `namespaces` in values.yaml and upgrade:

```bash
helm upgrade thingworx-secrets ./thingworx-external-secrets \
  --set namespaces[0].name=new-namespace
```

## Uninstallation

### Remove ExternalSecrets

```bash
helm uninstall thingworx-secrets
```

### Clean Up Secrets

The secrets created by ExternalSecrets will be cleaned up automatically due to `creationPolicy: Owner`. If you used `Orphan` policy, manually delete:

```bash
kubectl delete secret thingworx-secrets -n argo-cd
kubectl delete secret thingworx-secrets -n twx
```

## Best Practices

1. **Use ClusterSecretStore** for multi-namespace deployments to avoid duplication

2. **Set appropriate refresh intervals** - Balance between freshness and API rate limits
   - Production: `1h` or more
   - Development: `15m` to `30m`

3. **Use Managed Identity** instead of Service Principal when possible for better security

4. **Label and annotate** ExternalSecrets for better organization:
   ```yaml
   externalSecret:
     labels:
       app: thingworx
       environment: production
     annotations:
       owner: platform-team
   ```

5. **Monitor sync status** in production:
   ```bash
   kubectl get externalsecrets -A -o wide
   ```

6. **Use secret templates** for computed values instead of storing them in Key Vault

7. **Test in development** namespace first before deploying to production

## Security Considerations

- Never commit actual secret values to version control
- Use least privilege principle for Key Vault access
- Regularly rotate secrets in Key Vault
- Monitor External Secrets Operator logs for unauthorized access attempts
- Use network policies to restrict access to secrets
- Consider using Azure Private Link for Key Vault

## Integration with ArgoCD

If using with ArgoCD, add sync wave:

```yaml
# values.yaml
externalSecret:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"
```

Create ArgoCD Application:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: thingworx-secrets
  namespace: argocd
spec:
  project: default
  source:
    repoURL: <your-repo-url>
    targetRevision: HEAD
    path: thingworx-external-secrets
    helm:
      valueFiles:
        - values.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: external-secrets-system
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

## Additional Resources

- [External Secrets Operator Documentation](https://external-secrets.io/)
- [Azure Key Vault Provider](https://external-secrets.io/latest/provider/azure-key-vault/)
- [Kubernetes Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
