"""
cert_expiry_alert.py
--------------------
Runs continuously inside an AKS pod.
All configuration is read from environment variables injected by a Kubernetes ConfigMap + Secret.
The script wakes up every SCAN_INTERVAL_HOURS hours, reads the target Excel/CSV file
(mounted via a PVC or ConfigMap volume), checks expiry dates, and sends SMTP email alerts.
"""

import logging
import os
import smtplib
import sys
import time
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import pandas as pd

# ── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger(__name__)


# ── Read configuration from environment variables (injected by ConfigMap/Secret) ──

def get_env(key: str, default=None, required=False) -> str:
    val = os.environ.get(key, default)
    if required and not val:
        log.error("Missing required environment variable: %s", key)
        sys.exit(1)
    return val


# File
DATA_FILE           = get_env("DATA_FILE", "/data/certs.xlsx", required=True)

# SMTP  (host/port/user come from ConfigMap; password comes from Secret)
SMTP_HOST           = get_env("SMTP_HOST", required=True)
SMTP_PORT           = int(get_env("SMTP_PORT", "587"))
SMTP_USER           = get_env("SMTP_USER", required=True)
SMTP_PASSWORD       = get_env("SMTP_PASSWORD", required=True)   # mounted from Secret
SMTP_USE_TLS        = get_env("SMTP_USE_TLS", "true").lower() == "true"

# Recipients  (comma-separated list)
ALERT_RECIPIENTS    = [e.strip() for e in get_env("ALERT_RECIPIENTS", required=True).split(",")]

# How many days ahead to warn
WARN_DAYS           = int(get_env("WARN_DAYS", "30"))

# How often to re-scan (hours)
SCAN_INTERVAL_HOURS = float(get_env("SCAN_INTERVAL_HOURS", "24"))

# Date columns to check (comma-separated, matches your spreadsheet headers)
DATE_COLUMNS_RAW    = get_env(
    "DATE_COLUMNS",
    "Ingress-cert,SSO-cert,AKS Version- End of life,PTC License,ProvisioningKe,emessagekey,TWX_AppKey",
)
DATE_COLUMNS        = [c.strip() for c in DATE_COLUMNS_RAW.split(",")]

# Columns used to identify a row in the alert email
IDENTITY_COLS_RAW   = get_env("IDENTITY_COLUMNS", "TWX_AppKey,Azure AD -Client ID,Logtools B2C- Client ID")
IDENTITY_COLUMNS    = [c.strip() for c in IDENTITY_COLS_RAW.split(",")]


# ── Data loading ──────────────────────────────────────────────────────────────

def load_file(filepath: str) -> pd.DataFrame:
    p = Path(filepath)
    if not p.exists():
        raise FileNotFoundError(f"Data file not found: {filepath}")

    ext = p.suffix.lower()
    if ext in (".xlsx", ".xlsm", ".xls"):
        sheets = pd.read_excel(filepath, sheet_name=None, dtype=str)
        frames = []
        for name, df in sheets.items():
            df["_sheet"] = name
            frames.append(df)
        return pd.concat(frames, ignore_index=True)
    elif ext == ".csv":
        return pd.read_csv(filepath, dtype=str)
    else:
        raise ValueError(f"Unsupported file type: {ext}")


def parse_dates(df: pd.DataFrame) -> pd.DataFrame:
    for col in DATE_COLUMNS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce", infer_datetime_format=True)
    return df


def row_identity(row: pd.Series) -> str:
    parts = []
    for col in IDENTITY_COLUMNS:
        if col in row.index:
            val = str(row[col]).strip()
            if val and val.lower() != "nan":
                parts.append(f"{col}: {val}")
    return " | ".join(parts) if parts else f"Row {row.name}"


def find_expiring(df: pd.DataFrame) -> list[dict]:
    today    = datetime.now().date()
    deadline = today + timedelta(days=WARN_DAYS)
    alerts   = []

    existing = [c for c in DATE_COLUMNS if c in df.columns]
    for _, row in df.iterrows():
        identity = row_identity(row)
        for col in existing:
            val = row[col]
            if pd.isna(val):
                continue
            exp = val.date()
            days_left = (exp - today).days
            if exp <= deadline:
                alerts.append({
                    "identity"    : identity,
                    "column"      : col,
                    "expiry_date" : exp.strftime("%Y-%m-%d"),
                    "days_left"   : days_left,
                    "status"      : "EXPIRED" if exp < today else "EXPIRING SOON",
                    "sheet"       : row.get("_sheet", "—"),
                })
    return alerts


# ── Email ─────────────────────────────────────────────────────────────────────

def build_html(alerts: list[dict]) -> str:
    expired  = [a for a in alerts if a["status"] == "EXPIRED"]
    expiring = [a for a in alerts if a["status"] == "EXPIRING SOON"]

    def rows(items):
        html = ""
        for a in items:
            color = "#c0392b" if a["status"] == "EXPIRED" else "#d35400"
            html += f"""
            <tr>
              <td>{a['identity']}</td><td>{a['column']}</td>
              <td>{a['expiry_date']}</td>
              <td style="color:{color};font-weight:bold">{a['status']} ({a['days_left']}d)</td>
              <td>{a['sheet']}</td>
            </tr>"""
        return html

    def section(title, bg, items):
        if not items:
            return ""
        return f"""
        <h3 style="color:{bg}">{title} — {len(items)} item(s)</h3>
        <table>
          <thead style="background:{bg};color:#fff">
            <tr><th>Identity</th><th>Field</th><th>Expiry</th><th>Status</th><th>Sheet</th></tr>
          </thead>
          <tbody>{rows(items)}</tbody>
        </table>"""

    return f"""<html><head><style>
      body{{font-family:Arial,sans-serif;color:#222;max-width:960px;margin:auto;padding:20px}}
      h2{{background:#1a252f;color:#fff;padding:14px 20px;border-radius:6px}}
      table{{border-collapse:collapse;width:100%;margin-bottom:20px;font-size:13px}}
      th,td{{border:1px solid #ddd;padding:7px 10px;text-align:left}}
      tr:nth-child(even){{background:#f9f9f9}}
      p{{margin:4px 0}}
    </style></head><body>
      <h2>🔔 Certificate / License Expiry Alert</h2>
      <p>Scan time : <b>{datetime.now().strftime('%Y-%m-%d %H:%M UTC')}</b></p>
      <p>Source file: <b>{DATA_FILE}</b></p>
      <p>Warning window: <b>{WARN_DAYS} days</b> &nbsp;|&nbsp;
         Total alerts: <b>{len(alerts)}</b>
         (Expired: <b>{len(expired)}</b>, Expiring soon: <b>{len(expiring)}</b>)</p>
      {section('🚨 Already Expired', '#c0392b', expired)}
      {section(f'⚠️ Expiring Within {WARN_DAYS} Days', '#d35400', expiring)}
      <hr><p style="font-size:11px;color:#999">
        Auto-generated by cert-expiry-monitor running in AKS pod {os.environ.get('HOSTNAME','unknown')}
      </p>
    </body></html>"""


def send_alert(alerts: list[dict]):
    subject = (
        f"[CERT ALERT] {len(alerts)} item(s) expiring/expired — "
        f"{datetime.now().strftime('%Y-%m-%d')}"
    )
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = SMTP_USER
    msg["To"]      = ", ".join(ALERT_RECIPIENTS)
    msg.attach(MIMEText(build_html(alerts), "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as srv:
            srv.ehlo()
            if SMTP_USE_TLS:
                srv.starttls()
                srv.ehlo()
            srv.login(SMTP_USER, SMTP_PASSWORD)
            srv.sendmail(SMTP_USER, ALERT_RECIPIENTS, msg.as_string())
        log.info("Email sent to: %s", ", ".join(ALERT_RECIPIENTS))
    except Exception as exc:
        log.error("Failed to send email: %s", exc)


# ── Main loop ─────────────────────────────────────────────────────────────────

def scan():
    log.info("Starting scan — file: %s, warn_days: %d", DATA_FILE, WARN_DAYS)
    try:
        df     = load_file(DATA_FILE)
        df     = parse_dates(df)
        alerts = find_expiring(df)
        log.info("Scan complete — %d alert(s) found", len(alerts))

        if alerts:
            for a in alerts:
                log.warning("[%s] %s | %s | expires %s (%d days)",
                            a["status"], a["identity"], a["column"],
                            a["expiry_date"], a["days_left"])
            send_alert(alerts)
        else:
            log.info("No certificates expiring within %d days.", WARN_DAYS)

    except FileNotFoundError as e:
        log.error("%s", e)
    except Exception as e:
        log.exception("Unexpected error during scan: %s", e)


def main():
    log.info("=== cert-expiry-monitor started ===")
    log.info("Scan interval: %.1f hour(s)", SCAN_INTERVAL_HOURS)
    log.info("Recipients   : %s", ALERT_RECIPIENTS)

    while True:
        scan()
        sleep_sec = SCAN_INTERVAL_HOURS * 3600
        log.info("Next scan in %.1f hour(s). Sleeping …", SCAN_INTERVAL_HOURS)
        time.sleep(sleep_sec)


if __name__ == "__main__":
    main()
