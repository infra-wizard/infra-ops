# cert-expiry-monitor

A Python pod that runs **continuously** inside AKS, reads certificate/license
expiry dates from an Excel or CSV file, and sends SMTP email alerts.

---

## Project structure

```
cert-expiry-monitor/
├── cert_expiry_alert.py      # Main application
├── Dockerfile
├── requirements.txt
└── k8s/
    ├── configmap.yaml        # All non-secret settings
    ├── secret.yaml           # SMTP password
    ├── pvc.yaml              # PersistentVolumeClaim for the data file
    └── deployment.yaml       # AKS Deployment
```

---

## How it works

```
┌─────────────────────────────────────────────────────────────────┐
│                          AKS Pod                                │
│                                                                 │
│  ┌───────────────┐   envFrom   ┌──────────────────────────┐    │
│  │   ConfigMap   │ ──────────► │                          │    │
│  │  (settings)   │             │   cert_expiry_alert.py   │    │
│  └───────────────┘             │                          │    │
│                                │  loop every N hours:     │    │
│  ┌───────────────┐   env       │  1. read Excel/CSV       │    │
│  │    Secret     │ ──────────► │  2. find expiring rows   │    │
│  │ (SMTP passwd) │             │  3. send SMTP email      │    │
│  └───────────────┘             │                          │    │
│                                └──────────┬───────────────┘    │
│  ┌───────────────┐  volumeMount           │                    │
│  │  PVC / file   │ ──────────────────────►│ /data/certs.xlsx   │
│  └───────────────┘                        │                    │
└──────────────────────────────────────────-┴────────────────────┘
                                            │
                                            ▼  SMTP
                                    📧 Alert email
```

---

## Step-by-step deployment

### 1. Edit ConfigMap

Open `k8s/configmap.yaml` and set:

| Key | Description |
|-----|-------------|
| `SMTP_HOST` | Your SMTP server hostname |
| `SMTP_PORT` | Usually 587 (TLS) or 465 (SSL) |
| `SMTP_USER` | Sender email address |
| `ALERT_RECIPIENTS` | Comma-separated recipient addresses |
| `WARN_DAYS` | Days before expiry to start alerting (default 30) |
| `SCAN_INTERVAL_HOURS` | How often to re-scan (default 24) |
| `DATE_COLUMNS` | Comma-separated column names to check |

### 2. Edit Secret

Open `k8s/secret.yaml` and replace the placeholder with your SMTP password.

> **Tip for production**: Use Azure Key Vault + the Secrets Store CSI driver
> instead of committing passwords to YAML.

### 3. Build and push the Docker image

```bash
# Log in to your Azure Container Registry
az acr login --name <YOUR_ACR>

# Build
docker build -t <YOUR_ACR>.azurecr.io/cert-expiry-monitor:latest .

# Push
docker push <YOUR_ACR>.azurecr.io/cert-expiry-monitor:latest
```

### 4. Upload your Excel/CSV to the PVC

```bash
# Create the PVC first
kubectl apply -f k8s/pvc.yaml

# Spin up a temporary pod to copy the file onto the PVC
kubectl run uploader --image=busybox --restart=Never \
  --overrides='{"spec":{"volumes":[{"name":"data","persistentVolumeClaim":{"claimName":"cert-data-pvc"}}],"containers":[{"name":"uploader","image":"busybox","command":["sleep","3600"],"volumeMounts":[{"name":"data","mountPath":"/data"}]}]}}'

# Copy file into the PVC
kubectl cp certs.xlsx uploader:/data/certs.xlsx

# Remove the temp pod
kubectl delete pod uploader
```

> **Alternative** — if the file is small (< 1 MB), store it directly in a ConfigMap:
> ```bash
> kubectl create configmap cert-data-file --from-file=certs.xlsx
> ```
> Then replace the `persistentVolumeClaim` block in `deployment.yaml` with:
> ```yaml
> configMap:
>   name: cert-data-file
> ```

### 5. Deploy everything

```bash
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/deployment.yaml
```

### 6. Verify

```bash
# Watch pod startup
kubectl get pods -l app=cert-expiry-monitor -w

# Stream logs (real-time)
kubectl logs -l app=cert-expiry-monitor -f

# Expected log output:
# 2025-01-15 08:00:00 [INFO] === cert-expiry-monitor started ===
# 2025-01-15 08:00:00 [INFO] Scan interval: 24.0 hour(s)
# 2025-01-15 08:00:00 [INFO] Starting scan — file: /data/certs.xlsx, warn_days: 30
# 2025-01-15 08:00:01 [INFO] Scan complete — 3 alert(s) found
# 2025-01-15 08:00:01 [WARNING] [EXPIRING SOON] TWX_AppKey: dev2 | Ingress-cert | expires 2026-02-10 (25 days)
# 2025-01-15 08:00:01 [INFO] Email sent to: team@yourcompany.com
# 2025-01-15 08:00:01 [INFO] Next scan in 24.0 hour(s). Sleeping …
```

---

## Updating configuration without restarting

ConfigMap values are re-read **on the next scan cycle** (the pod reads env vars
at startup). To apply config changes immediately:

```bash
kubectl apply -f k8s/configmap.yaml
kubectl rollout restart deployment/cert-expiry-monitor
```

## Updating the data file

If you used a PVC:
```bash
kubectl run uploader --image=busybox --restart=Never \
  --overrides='...'   # same as step 4
kubectl cp certs_updated.xlsx uploader:/data/certs.xlsx
kubectl delete pod uploader
# No pod restart needed — file is re-read every scan cycle
```

If you used a ConfigMap:
```bash
kubectl create configmap cert-data-file --from-file=certs.xlsx --dry-run=client -o yaml \
  | kubectl apply -f -
kubectl rollout restart deployment/cert-expiry-monitor
```

---

## Environment variable reference

| Variable | Source | Default | Description |
|----------|--------|---------|-------------|
| `DATA_FILE` | ConfigMap | `/data/certs.xlsx` | Path to Excel/CSV inside pod |
| `SMTP_HOST` | ConfigMap | — | SMTP server hostname |
| `SMTP_PORT` | ConfigMap | `587` | SMTP port |
| `SMTP_USER` | ConfigMap | — | Sender address / login |
| `SMTP_USE_TLS` | ConfigMap | `true` | Enable STARTTLS |
| `SMTP_PASSWORD` | **Secret** | — | SMTP password |
| `ALERT_RECIPIENTS` | ConfigMap | — | Comma-separated email list |
| `WARN_DAYS` | ConfigMap | `30` | Days-ahead warning window |
| `SCAN_INTERVAL_HOURS` | ConfigMap | `24` | Hours between scans |
| `DATE_COLUMNS` | ConfigMap | (see configmap) | Columns to check |
| `IDENTITY_COLUMNS` | ConfigMap | (see configmap) | Columns for row labels |
