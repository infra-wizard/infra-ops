# Providers Helm Chart

This Helm chart deploys the Providers application on Kubernetes/OpenShift with Azure Key Vault integration.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Azure Key Vault CSI Driver installed
- Access to Azure Key Vault
- Harbor registry credentials

## Installation

### Install the chart

```bash
helm install providers ./providers-helm -n lumen
```

### Install with custom values

```bash
helm install providers ./providers-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade providers ./providers-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall providers -n lumen
```

## Configuration

The following table lists the configurable parameters of the Providers chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/providers/providers` |
| `image.tag` | Image tag | `db2ca1dc5e9c3623c6ae8ea01317ff5f29e290d2-20260123-232525` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `providers-dev-lumen.matrixmedical.cloud` |
| `env.aspnetcoreEnvironment` | ASP.NET Core environment | `Development` |
| `env.dotnetStartupProject` | .NET startup project | `ProviderAPI/ProviderAPI.csproj` |
| `env.clientIdsToSync` | Client IDs to sync | `24, 34, 46, 64, 94, 118, 259, 294, 307` |
| `env.clientStateNames` | Client state names | `VA,MD,SC,NJ` |
| `secretProviderClass.enabled` | Enable Azure Key Vault integration | `true` |
| `secretProviderClass.keyvaultName` | Azure Key Vault name | `kv-provider-dev` |
| `secretProviderClass.tenantId` | Azure Tenant ID | `07497e85-9665-4d82-9d54-ea2496a522d9` |

## Examples

### Deploy to production

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  tag: production-latest

env:
  aspnetcoreEnvironment: Production
  clientIdsToSync: '24, 34, 46, 64, 94, 118, 259, 294, 307, 400, 500'
  clientStateNames: 'VA,MD,SC,NJ,NY,CA'

route:
  host: providers-prod-lumen.matrixmedical.cloud

secretProviderClass:
  keyvaultName: kv-provider-prod
```

Then install:

```bash
helm install providers ./providers-helm -n lumen -f values-prod.yaml
```

### Update image tag only

```bash
helm upgrade providers ./providers-helm -n lumen \
  --set image.tag=newversion123
```

### Update client configuration

```bash
helm upgrade providers ./providers-helm -n lumen \
  --set env.clientIdsToSync='24, 34, 46' \
  --set env.clientStateNames='VA,MD'
```

## Notes

- The chart uses Azure Key Vault CSI Driver to mount secrets
- Secrets are automatically synced from Azure Key Vault
- The SecretProviderClass must be in the same namespace as the deployment
- Ensure the `secrets-store-creds` secret exists with proper Azure credentials
- Client IDs and state names can be configured via environment variables

## Secrets

The chart manages the following secrets from Azure Key Vault:

- Providers-AppConfig-BlobStore-SASToken
- Providers-AppConfig--Scheduler--DashboardCredentials--Password
- Providers-ConnectionStrings--DefaultConnectionString
- Providers-ConnectionStrings--LegacyConnectionString
- Providers-ConnectionStrings--LegacyReadConnectionString
- Providers-ConnectionStrings--LegacyWriteConnectionString
- Providers-ConnectionStrings--SmbPassword

## Environment Variables

The chart configures the following non-secret environment variables:

- **ASPNETCORE_ENVIRONMENT**: Application environment (Development/Production)
- **DOTNET_STARTUP_PROJECT**: .NET project to start
- **Providers_AppConfig__ClientIdsToSync**: Comma-separated list of client IDs
- **Providers_AppConfig__ClientStateNames**: Comma-separated state names
