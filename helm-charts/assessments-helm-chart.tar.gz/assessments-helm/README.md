# Assessments Helm Chart

This Helm chart deploys the Assessments application on Kubernetes/OpenShift with Azure Key Vault integration.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Azure Key Vault CSI Driver installed
- Access to Azure Key Vault
- Harbor registry credentials

## Installation

### Install the chart

```bash
helm install assessments ./assessments-helm -n lumen
```

### Install with custom values

```bash
helm install assessments ./assessments-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade assessments ./assessments-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall assessments -n lumen
```

## Configuration

The following table lists the configurable parameters of the Assessments chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/assessments/assessments` |
| `image.tag` | Image tag | `0d27f55bc306a0f1c77cf088030b65010f4c7288-20260126-202853` |
| `image.pullPolicy` | Image pull policy | `Always` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `assessments-dev-lumen.matrixmedical.cloud` |
| `env.aspnetcoreEnvironment` | ASP.NET Core environment | `Development` |
| `secretProviderClass.enabled` | Enable Azure Key Vault integration | `true` |
| `secretProviderClass.keyvaultName` | Azure Key Vault name | `kv-assessmentsvault-dev` |
| `secretProviderClass.tenantId` | Azure Tenant ID | `07497e85-9665-4d82-9d54-ea2496a522d9` |

## Examples

### Deploy to a different environment

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  tag: latest

env:
  aspnetcoreEnvironment: Production

route:
  host: assessments-prod-lumen.matrixmedical.cloud

secretProviderClass:
  keyvaultName: kv-assessmentsvault-prod
```

Then install:

```bash
helm install assessments ./assessments-helm -n lumen -f values-prod.yaml
```

### Update image tag only

```bash
helm upgrade assessments ./assessments-helm -n lumen \
  --set image.tag=newversion123
```

## Notes

- The chart uses Azure Key Vault CSI Driver to mount secrets
- Secrets are automatically synced from Azure Key Vault
- The SecretProviderClass must be in the same namespace as the deployment
- Ensure the `secrets-store-creds-assessments` secret exists with proper Azure credentials
