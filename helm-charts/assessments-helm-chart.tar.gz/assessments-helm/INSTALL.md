# Quick Installation Guide

## Prerequisites

Before installing this Helm chart, ensure you have:

1. **Kubernetes/OpenShift cluster** access
2. **Helm 3.x** installed
3. **Azure Key Vault CSI Driver** installed in the cluster
4. **Harbor registry credentials** configured
5. **Azure credentials secret** created:

```bash
kubectl create secret generic secrets-store-creds-assessments \
  --from-literal=clientid=<AZURE_CLIENT_ID> \
  --from-literal=clientsecret=<AZURE_CLIENT_SECRET> \
  -n lumen
```

## Installation Steps

### 1. Create namespace (if not exists)

```bash
kubectl create namespace lumen
```

### 2. Validate the chart

```bash
helm lint ./assessments-helm
```

### 3. Dry run to preview resources

```bash
helm install assessments ./assessments-helm -n lumen --dry-run --debug
```

### 4. Install the chart

```bash
helm install assessments ./assessments-helm -n lumen
```

### 5. Verify installation

```bash
# Check deployment status
kubectl get deployments -n lumen

# Check pods
kubectl get pods -n lumen

# Check service
kubectl get svc -n lumen

# Check route (OpenShift)
kubectl get route -n lumen

# Check SecretProviderClass
kubectl get secretproviderclass -n lumen
```

## Common Operations

### Upgrade with new image version

```bash
helm upgrade assessments ./assessments-helm -n lumen \
  --set image.tag=<NEW_TAG>
```

### View current values

```bash
helm get values assessments -n lumen
```

### Rollback to previous version

```bash
helm rollback assessments -n lumen
```

### Uninstall

```bash
helm uninstall assessments -n lumen
```

## Environment-Specific Deployments

### Development

```bash
helm install assessments ./assessments-helm -n lumen
```

### Production

Create `values-prod.yaml`:

```yaml
replicaCount: 3

env:
  aspnetcoreEnvironment: Production

route:
  host: assessments-prod-lumen.matrixmedical.cloud

secretProviderClass:
  keyvaultName: kv-assessmentsvault-prod
```

Install:

```bash
helm install assessments-prod ./assessments-helm -n lumen -f values-prod.yaml
```

## Troubleshooting

### Pods not starting

Check logs:
```bash
kubectl logs -n lumen -l app=assessments
```

### Secrets not mounted

Check SecretProviderClass:
```bash
kubectl describe secretproviderclass spc-assessments -n lumen
```

Check CSI driver:
```bash
kubectl get pods -n kube-system | grep secrets-store
```

### Image pull issues

Verify registry secret:
```bash
kubectl get secret harbor-registry-secret -n lumen
```

## Support

For issues or questions, please contact your DevOps team.
