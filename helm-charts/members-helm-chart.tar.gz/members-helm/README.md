# Members Helm Chart

This Helm chart deploys the Members application on Kubernetes/OpenShift with Azure Key Vault integration.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Azure Key Vault CSI Driver installed
- Access to Azure Key Vault
- Harbor registry credentials

## Installation

### Install the chart

```bash
helm install members ./members-helm -n lumen
```

### Install with custom values

```bash
helm install members ./members-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade members ./members-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall members -n lumen
```

## Configuration

The following table lists the configurable parameters of the Members chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/members/members` |
| `image.tag` | Image tag | `5dbbdf9e679ecb15a8f58ab1c20dae5d79f600e2-20251212-004108` |
| `image.pullPolicy` | Image pull policy | `Always` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `members-dev-lumen.matrixmedical.cloud` |
| `secretProviderClass.enabled` | Enable Azure Key Vault integration | `true` |
| `secretProviderClass.keyvaultName` | Azure Key Vault name | `kv-membersvault-dev` |
| `secretProviderClass.tenantId` | Azure Tenant ID | `07497e85-9665-4d82-9d54-ea2496a522d9` |

## Examples

### Deploy to production

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  tag: production-latest

route:
  host: members-prod-lumen.matrixmedical.cloud

secretProviderClass:
  keyvaultName: kv-membersvault-prod
```

Then install:

```bash
helm install members ./members-helm -n lumen -f values-prod.yaml
```

### Update image tag only

```bash
helm upgrade members ./members-helm -n lumen \
  --set image.tag=newversion123
```

## Notes

- The chart uses Azure Key Vault CSI Driver to mount secrets
- Secrets are automatically synced from Azure Key Vault
- The SecretProviderClass must be in the same namespace as the deployment
- Ensure the `secrets-store-creds-members` secret exists with proper Azure credentials

## Secrets

The chart manages the following secrets from Azure Key Vault:

- ASPNETCORE-ENVIRONMENT
- DOTNET-STARTUP-PROJECT
- Members-AppConfig--AzureSourceStore--SASToken
- Members-AppConfig--AzureTargetStore--SASToken
- Members-AppConfig--CouchbaseCredentials--Password
- Members-AppConfig--Scheduler--DashboardCredentials--Password
- Members-ConnectionStrings--LegacyReadConnectionString
- Members-ConnectionStrings--LegacyWriteConnectionString
- Members-ConnectionStrings--PostgreSQLConnectionString
- Members-ConnectionStrings--SmbPassword
