# Field Operations Helm Chart

This Helm chart deploys the Field Operations application on Kubernetes/OpenShift with Azure Key Vault integration and ArgoCD PostSync Job.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Azure Key Vault CSI Driver installed
- Access to Azure Key Vault
- Harbor registry credentials
- ArgoCD (optional, for PostSync job)

## Installation

### Install the chart

```bash
helm install fieldoperations ./fieldoperations-helm -n lumen
```

### Install with custom values

```bash
helm install fieldoperations ./fieldoperations-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade fieldoperations ./fieldoperations-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall fieldoperations -n lumen
```

## Configuration

The following table lists the configurable parameters of the Field Operations chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/fieldoperations/fieldoperations` |
| `image.tag` | Image tag | `527f8dbde56fa4a4478141ee9db87018d73f37c5-20250612-161358` |
| `image.pullPolicy` | Image pull policy | `Always` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `fieldoperations-dev-lumen.matrixmedical.cloud` |
| `job.enabled` | Enable PostSync job | `true` |
| `job.argocd.hook` | ArgoCD hook type | `PostSync` |
| `secretProviderClass.enabled` | Enable Azure Key Vault integration | `true` |
| `secretProviderClass.keyvaultName` | Azure Key Vault name | `kv-members-service-dev` |
| `secretProviderClass.tenantId` | Azure Tenant ID | `07497e85-9665-4d82-9d54-ea2496a522d9` |

## Examples

### Deploy to production

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  tag: production-latest

route:
  host: fieldoperations-prod-lumen.matrixmedical.cloud

secretProviderClass:
  keyvaultName: kv-members-service-prod
```

Then install:

```bash
helm install fieldoperations ./fieldoperations-helm -n lumen -f values-prod.yaml
```

### Update image tag only

```bash
helm upgrade fieldoperations ./fieldoperations-helm -n lumen \
  --set image.tag=newversion123
```

### Disable PostSync job

```bash
helm install fieldoperations ./fieldoperations-helm -n lumen \
  --set job.enabled=false
```

## Notes

- The chart uses Azure Key Vault CSI Driver to mount secrets
- Secrets are automatically synced from Azure Key Vault
- The PostSync job runs after ArgoCD sync (requires ArgoCD)
- The SecretProviderClass must be in the same namespace as the deployment
- Ensure the `secrets-store-creds-fieldoperations` secret exists with proper Azure credentials

## Secrets

The chart manages the following secrets from Azure Key Vault:

- ASPNETCORE-ENVIRONMENT
- DOTNET-STARTUP-PROJECT
- Logging--LogLevel--fieldoperations
- fieldoperations-AppConfig--CacheConfig--Uri
- fieldoperations-AppConfig--ScanKeyCacheConfig--Uri
- fieldoperations-ConnectionStrings--DefaultConnectionString
- fieldoperations-ConnectionStrings--LegacyReadConnectionString
- fieldoperations-ConnectionStrings--LegacyWriteConnectionString
- fieldoperations-ConnectionStrings--QueueConnectionString
- OLD-CacheConfig--Uri
