# Field Operations UI Helm Chart

This Helm chart deploys the Field Operations UI application on Kubernetes/OpenShift.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Harbor registry credentials

## Installation

### Install the chart

```bash
helm install field-operations-ui ./field-operations-ui-helm -n lumen
```

### Install with custom values

```bash
helm install field-operations-ui ./field-operations-ui-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade field-operations-ui ./field-operations-ui-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall field-operations-ui -n lumen
```

## Configuration

The following table lists the configurable parameters of the Field Operations UI chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/field-operations-ui/field-operations-ui` |
| `image.digest` | Image SHA256 digest | `sha256:44eee23f0623b24fdffe1ac2016b1f4aca4286cae84e66fae28d97db8459a353` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `service.targetPort` | Container port | `8080` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `field-operations-ui-dev-lumen.matrixmedical.cloud` |

## Examples

### Deploy to production

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  digest: sha256:newdigest123...

route:
  host: field-operations-ui-prod-lumen.matrixmedical.cloud
```

Then install:

```bash
helm install field-operations-ui ./field-operations-ui-helm -n lumen -f values-prod.yaml
```

### Using image tag instead of digest

If you prefer to use tags instead of digests, modify `values.yaml`:

```yaml
image:
  repository: harbor.matrixmedical.cloud/field-operations-ui/field-operations-ui
  tag: v1.2.3
  # digest: ""  # Comment out or remove digest
```

### Update image digest

```bash
helm upgrade field-operations-ui ./field-operations-ui-helm -n lumen \
  --set image.digest=sha256:newdigest456...
```

## Notes

- The chart requires the `harbor-registry-secret` to be present in the namespace
- The chart uses image digest by default for immutable deployments
- The route is OpenShift-specific and can be disabled by setting `route.enabled=false`
- Image digests ensure you're deploying the exact same image every time

## Image Digest vs Tag

This chart uses SHA256 digest by default (e.g., `@sha256:44eee23f...`) instead of tags. Benefits:

- **Immutability**: Digest references a specific image that never changes
- **Security**: Ensures you deploy the exact image you tested
- **Reliability**: Tags can be overwritten; digests cannot

To switch to tag-based deployments, comment out `digest` and add `tag` in values.yaml.
