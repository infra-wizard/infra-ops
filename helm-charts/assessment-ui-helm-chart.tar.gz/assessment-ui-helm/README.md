# Assessment UI Helm Chart

This Helm chart deploys the Assessment UI application on Kubernetes/OpenShift.

## Prerequisites

- Kubernetes 1.19+ or OpenShift 4.x+
- Helm 3.0+
- Harbor registry credentials

## Installation

### Install the chart

```bash
helm install assessment-ui ./assessment-ui-helm -n lumen
```

### Install with custom values

```bash
helm install assessment-ui ./assessment-ui-helm -n lumen -f custom-values.yaml
```

### Upgrade the chart

```bash
helm upgrade assessment-ui ./assessment-ui-helm -n lumen
```

### Uninstall the chart

```bash
helm uninstall assessment-ui -n lumen
```

## Configuration

The following table lists the configurable parameters of the Assessment UI chart and their default values.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `2` |
| `image.repository` | Image repository | `harbor.matrixmedical.cloud/assessments-ui/assessments-ui` |
| `image.tag` | Image tag | `development-fb6f00e4a4989a055f6b27f0764533b95a7ad486-20241219-153247` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `80` |
| `service.targetPort` | Container port | `8080` |
| `route.enabled` | Enable OpenShift route | `true` |
| `route.host` | Route hostname | `assessments-ui-dev-lumen.matrixmedical.cloud` |

## Examples

### Deploy to production

Create a `values-prod.yaml` file:

```yaml
replicaCount: 3

image:
  tag: production-latest

route:
  host: assessments-ui-prod-lumen.matrixmedical.cloud
```

Then install:

```bash
helm install assessment-ui ./assessment-ui-helm -n lumen -f values-prod.yaml
```

### Update image tag only

```bash
helm upgrade assessment-ui ./assessment-ui-helm -n lumen \
  --set image.tag=newversion123
```

## Notes

- The chart requires the `harbor-registry-secret` to be present in the namespace
- The route is OpenShift-specific and can be disabled by setting `route.enabled=false`
