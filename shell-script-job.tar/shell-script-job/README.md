# Shell Script Job Helm Chart

A Helm chart for running a shell script as a Kubernetes Job.

## Features

- Run custom shell scripts as Kubernetes Jobs
- Configurable job parameters (retries, timeouts, parallelism)
- Security best practices enabled by default
- Resource limits and requests
- Service account support
- Environment variable injection
- Node selector, tolerations, and affinity support

## Installation

### Basic Installation

```bash
helm install my-job ./shell-script-job
```

### Installation with Custom Script

Create a custom values file:

```yaml
# custom-values.yaml
script: |
  #!/bin/sh
  echo "Running my custom script"
  # Your script logic here
  curl -X POST https://api.example.com/webhook
  echo "Script completed"

image:
  repository: curlimages/curl
  tag: "latest"
```

Install with custom values:

```bash
helm install my-job ./shell-script-job -f custom-values.yaml
```

### Installation with Environment Variables

```yaml
# values-with-env.yaml
script: |
  #!/bin/sh
  echo "API URL: $API_URL"
  echo "Environment: $ENVIRONMENT"

env:
  - name: API_URL
    value: "https://api.example.com"
  - name: ENVIRONMENT
    value: "production"
```

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `job.backoffLimit` | Number of retries before marking job as failed | `3` |
| `job.activeDeadlineSeconds` | Time in seconds before job is terminated | `300` |
| `job.completions` | Number of successful completions required | `1` |
| `job.parallelism` | Number of pods to run in parallel | `1` |
| `job.ttlSecondsAfterFinished` | TTL in seconds after job finishes | `100` |
| `image.repository` | Container image repository | `busybox` |
| `image.tag` | Container image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `script` | Shell script to execute | Sample script |
| `resources.limits.cpu` | CPU limit | `100m` |
| `resources.limits.memory` | Memory limit | `128Mi` |
| `resources.requests.cpu` | CPU request | `50m` |
| `resources.requests.memory` | Memory request | `64Mi` |
| `serviceAccount.create` | Create service account | `true` |
| `env` | Environment variables | `[]` |
| `envFrom` | Environment from secrets/configmaps | `[]` |
| `volumes` | Additional volumes to mount | `[]` |
| `volumeMounts` | Additional volume mounts | `[]` |

## Examples

### Running a Database Backup Job

```yaml
script: |
  #!/bin/sh
  pg_dump -h $DB_HOST -U $DB_USER $DB_NAME > /backup/dump.sql
  aws s3 cp /backup/dump.sql s3://$BUCKET_NAME/backups/$(date +%Y%m%d).sql

image:
  repository: postgres
  tag: "15"

env:
  - name: DB_HOST
    value: "postgres.default.svc.cluster.local"
  - name: DB_USER
    value: "postgres"
  - name: DB_NAME
    value: "myapp"
  - name: BUCKET_NAME
    value: "my-backups"

envFrom:
  - secretRef:
      name: db-credentials

resources:
  limits:
    cpu: 500m
    memory: 512Mi
```

### Running a Data Processing Job

```yaml
script: |
  #!/usr/bin/env python3
  import sys
  print("Processing data...")
  # Your Python logic here
  print("Done!")

image:
  repository: python
  tag: "3.11-slim"

job:
  backoffLimit: 5
  activeDeadlineSeconds: 600
```

### Thingworx AKS Deployment

For deploying Thingworx to Azure Kubernetes Service, use the included `values-thingworx.yaml` configuration:

**Prerequisites:**
1. Azure Service Principal or Managed Identity with permissions to:
   - Access Azure Key Vault
   - Manage AKS resources
   - Create/manage Azure Storage accounts and file shares
   - Pull from Azure Container Registry

2. Kubernetes secrets created for Azure authentication:
```bash
# Create Azure credentials secret
kubectl create secret generic azure-sp-credentials \
  --from-literal=AZURE_CLIENT_ID=<client-id> \
  --from-literal=AZURE_CLIENT_SECRET=<client-secret> \
  --from-literal=AZURE_TENANT_ID=<tenant-id>

# Create configmaps for certificates and templates
kubectl create configmap thingworx-certificates --from-file=./certificates/
kubectl create configmap thingworx-helm-charts --from-file=./ingress-nginx/
kubectl create configmap thingworx-templates --from-file=./infrastructure/
```

3. Required files structure:
```
.
├── certificates/
│   └── ingress/
│       └── [REGCODE]/
│           └── [ENV]-cert/
│               ├── cert-[REGCODE].cer
│               └── cert-[REGCODE]-private.key
├── ingress-nginx/
│   ├── valuesTemplate.yaml
│   └── twx-ingressTemplate.yaml
├── infrastructure/
│   ├── files-storage-classTemplate.yaml
│   └── file-repo-classTemplate.yaml
└── replaceValues.sh
```

**Installation:**

```bash
# Install with Thingworx configuration
helm install thingworx-deploy ./shell-script-job \
  -f ./shell-script-job/values-thingworx.yaml \
  --set env[0].value="d3" \
  --set env[1].value="521"

# Monitor the job
kubectl get jobs -w
kubectl logs -f job/thingworx-deploy-shell-script-job

# Check deployment status
kubectl get pods -n thingworx
kubectl get ingress -n ingress
```

**Configuration Parameters:**

| Environment Variable | Description | Example Values |
|---------------------|-------------|----------------|
| `ENV` | Environment name | `d2`, `d3`, `q1`, `p1` |
| `REGCODE` | Region code | `521` (global), `811` (china) |
| `REG` | Region identifier | `global`, `china` |

**Key Features:**
- Deploys cert-manager for certificate management
- Configures ingress-nginx with Azure Load Balancer
- Creates necessary namespaces and RBAC
- Sets up Azure Storage with file shares (supports NFS)
- Configures monitoring with Prometheus and Grafana
- Handles SSO configuration via Azure AD
- Automatic retry logic with configurable backoff

**Troubleshooting:**

```bash
# View job logs
kubectl logs job/thingworx-deploy-shell-script-job

# Describe job for events
kubectl describe job thingworx-deploy-shell-script-job

# Check secret creation
kubectl get secrets -n thingworx

# Verify storage classes
kubectl get storageclass

# Check ingress status
kubectl get ingress -n ingress -o wide
```

## Uninstallation

```bash
helm uninstall my-job
```

## Notes

- The script is stored in a ConfigMap and mounted as a volume
- Default security context runs as non-root user (UID 1000)
- Read-only root filesystem is enabled by default
- Jobs are automatically cleaned up after completion (default: 100 seconds)
