# Thingworx AKS Deployment Setup Guide

This guide provides step-by-step instructions for deploying Thingworx to Azure Kubernetes Service (AKS) using this Helm chart.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Azure Resources Required](#azure-resources-required)
3. [Preparing Configuration Files](#preparing-configuration-files)
4. [Creating Kubernetes Secrets](#creating-kubernetes-secrets)
5. [Deployment](#deployment)
6. [Troubleshooting](#troubleshooting)

## Prerequisites

### Tools Required

Ensure the following tools are installed on your local machine:

- `kubectl` (v1.24+)
- `helm` (v3.10+)
- `az` CLI (Azure CLI v2.45+)

### Azure Permissions

The Azure Service Principal or Managed Identity must have the following permissions:

- **Key Vault**: `Key Vault Secrets User` or `Key Vault Administrator`
- **AKS**: `Azure Kubernetes Service Cluster User Role` or `Azure Kubernetes Service Cluster Admin Role`
- **Storage**: `Storage Account Contributor`
- **Container Registry**: `AcrPull` and `AcrPush`

### Kubernetes Cluster Access

Ensure you have access to the target AKS cluster:

```bash
# Login to Azure
az login

# Set subscription
az account set --subscription <subscription-id>

# Get AKS credentials
az aks get-credentials --resource-group <resource-group> --name <aks-cluster-name>

# Verify access
kubectl cluster-info
```

## Azure Resources Required

### Azure Key Vaults

The script expects secrets to be stored in three Azure Key Vaults:

1. **Build Key Vault**: `${ENV}-al-bld-kv${REGCODE}`
   - Contains configuration parameters (87 secrets)
   - Example: `d3-al-bld-kv521` for dev3 global

2. **Database Key Vault**: `${ENV}-al-twxpgf-kv${REGCODE}`
   - Contains database credentials (8 secrets)
   - Example: `d3-al-twxpgf-kv521` for dev3 global

3. **Thingworx Key Vault**: `${ENV}-al-twx-kv${REGCODE}`
   - Contains ingress IP configuration
   - Example: `d3-al-twx-kv521` for dev3 global

### Required Secrets in Key Vault

The following secrets must exist in the Build Key Vault (`${ENV}-al-bld-kv${REGCODE}`):

<details>
<summary>Click to expand full list of 87 required secrets</summary>

```
${ENV}-AKSREGCODE
${ENV}-AKS-NS
${ENV}-ACR-TWX-SERVER
${ENV}-ACR-TWX-USER
${ENV}-AKS-PERS-LOCATION
${ENV}-AKS-PERS-RESOURCE-GROUP
${ENV}-AKS-PERS-SHARE-NAME
${ENV}-AKS-PERS-SHARE-NAME-SKUNAME
${ENV}-AKS-PERS-STORAGE-ACCOUNT-NAME
${ENV}-AKS-FR-RESOURCE-GROUP
${ENV}-AKS-FR-STORAGE-ACCOUNT-NAME
${ENV}-AKS-FR-STORAGE-SHARENAME
${ENV}-AKS-FR-SHARE-NAME-SKUNAME
${ENV}-AKS-MONITORING-STORAGE-ACCOUNT-NAME
${ENV}-AKS-MONITORING-RESOURCE-GROUP
${ENV}-AKS-TWX-INGRESS-CERT
${ENV}-INGRESS-IP
${ENV}-TWX-LS-KEY
${ENV}-SSL-KEYSTORE-PASSWORD
${ENV}-KEYSTORE-PASSWORD
${ENV}-THINGWORX-INITIAL-ADMIN-PASSWORD
${ENV}-TOMCAT-CLIENT-PASSWORD
${ENV}-TOMCAT-TRUSTSTORE-PASSWORD
${ENV}-TWX-EMS-URL
${ENV}-TWX-ENABLE-CONSOLE-OUTPUT
${ENV}-TWX-ENABLE-CLUSTERED-MODE
${ENV}-TWX-SECRET-PROVISIONING-APP-KEY
${ENV}-TWX-PLATFORM-ID
${ENV}-TWX-POOL-NAME
${ENV}-TWX-REPLICA-COUNT
${ENV}-TWX-CPU-REQUEST
${ENV}-TWX-CPU-LIMIT
${ENV}-TWX-MEMORY-REQUEST
${ENV}-TWX-MEMORY-LIMIT
${ENV}-TWX-CATALINA-OPTS
${ENV}-EMG-REPLICA-COUNT
${ENV}-EMESSAGE-POOL-NAME
${ENV}-EMG-CPU-REQUEST
${ENV}-EMG-CPU-LIMIT
${ENV}-EMG-MEMORY-REQUEST
${ENV}-EMG-MEMORY-LIMIT
${ENV}-EMG-CATALINA-OPTS
${ENV}-ZOOKEEPER-PORT
${ENV}-TWX-HTTP-PORT
${ENV}-TWX-HTTPS-PORT
${ENV}-TWX-ENABLE-SSO
${ENV}-TWX-SSO-IDP-URL
${ENV}-TWX-MAIN-URL
${ENV}-TWX-ENCRYPT-CREDENTIALS
${ENV}-EMESSAGE-CONNECTOR-APP-ID
${ENV}-THINGWORX-EXPORTER-APP-ID
${ENV}-SCRIPT-TIMEOUT
${ENV}-THINGWORX-INITIAL-METRICS-USER-PASSWORD
${ENV}-IS-AZURE-POSTGRES
${ENV}-PGSSLMODE
${ENV}-SSO-JKS
${ENV}-SSO-GROUP-MAPPING
${ENV}-SSO-KEYSTORE-STOREPASS
${ENV}-SSO-KEYSTORE-KEYPASS
${ENV}-SSO-TWX-TENANT-ID
${ENV}-TWX-METADATA-ENTITY-ID
${ENV}-SSO-RS-CLIENTID
${ENV}-SSO-RS-SECRET
${ENV}-SSO-RS-SCOPE
${ENV}-storage-twxstorage-size
${ENV}-storage-twxstorage-shareName
${ENV}-storage-twxstorage-volumeName
${ENV}-storage-twxstorage-existingClaim
${ENV}-storage-twxstorage-enabled
${ENV}-storage-twadminhome-size
${ENV}-storage-twadminhome-shareName
${ENV}-storage-twadminhome-existingClaim
${ENV}-storage-twadminhome-volumeName
${ENV}-storage-twadminhome-enabled
${ENV}-storage-twxplatform-size
${ENV}-storage-twxplatform-enabled
${ENV}-storage-storage-className
${ENV}-FR-STORAGE-CLASSNAME
${ENV}-FR-STORAGE-SIZE
${ENV}-FR-STORAGE-VOLUMENAME
${ENV}-FR-STORAGE-EXISTINGCLAIM
${ENV}-FR-STORAGE-ENABLED
${ENV}-AKS-FR-STORAGE-IS-NFS
${ENV}-ABT-IMAGE-TAG
${ENV}-EMG-IMAGE-TAG
${ENV}-TWX-IMAGE-TAG
${ENV}-TWX-JMX-IMAGE-TAG
```
</details>

Database Key Vault secrets (`${ENV}-al-twxpgf-kv${REGCODE}`):

```
${ENV}-TWX-DATA-DATABASE-USERNAME
${ENV}-TWX-DATA-DATABASE-PASSWORD
${ENV}-TWX-DATABASE-PASSWORD
${ENV}-TWX-DATABASE-USERNAME
${ENV}-DATABASE-HOST
${ENV}-DATABASE-PORT
${ENV}-DATABASE-ADMIN-USERNAME
${ENV}-DATABASE-ADMIN-PASSWORD
```

Thingworx Key Vault secrets (`${ENV}-al-twx-kv${REGCODE}`):

```
${ENV}-AL-TWX-AKS${AKSREGCODE}-INGRESS-IP
```

### Azure Storage Accounts

Two storage accounts are required:

1. **Thingworx Platform Storage**: Stores Thingworx platform files
2. **File Repository Storage**: Stores Thingworx file repository (supports NFS)

### Azure Container Registry (ACR)

An Azure Container Registry with the following images:

- Thingworx application image
- eMessage service image
- Supporting tools images

## Preparing Configuration Files

### 1. Directory Structure

Create the following directory structure:

```
workspace/
├── certificates/
│   └── ingress/
│       ├── 521/              # Global region
│       │   └── d3-cert/      # Environment-specific
│       │       ├── cert-521.cer
│       │       └── cert-521-private.key
│       └── 811/              # China region
│           └── d3-cert/
│               ├── cert-811.cer
│               └── cert-811-private.key
├── ingress-nginx/
│   ├── valuesTemplate.yaml
│   ├── twx-ingressTemplate.yaml
│   └── custom-default-backendTemplate.yaml
├── cert-manager/
│   └── valuesTemplate.yaml
├── infrastructure/
│   ├── files-storage-classTemplate.yaml
│   ├── file-repo-classTemplate.yaml
│   ├── cert-manager-values.yaml
│   ├── cert-manager-validation-ca.yaml
│   ├── cert-manager-validation-issuer.yaml
│   └── cert-manager-validation-cert.yaml
├── kube-prometheus-stack/
│   ├── valuesTemplate.yaml
│   └── stable-prometheus-operator-valuesTemplate.yaml
├── loki-stack/
│   └── valuesTemplate.yaml
├── deployment/
│   ├── thingworxTemplate.yaml
│   └── thingworxSSOTemplate.yaml
├── common.yaml
├── commonTemplate.env
└── replaceValues.sh
```

### 2. Certificate Preparation

Generate or obtain SSL certificates for ingress:

```bash
# Generate CSR (if needed)
openssl req -new -newkey rsa:4096 -nodes \
  -keyout cert-${REGCODE}-private.key \
  -out cert-${REGCODE}.csr \
  -subj "/CN=*.your-domain.com"

# Submit CSR to your certificate authority
# Place the signed certificate and private key in the appropriate directory
```

### 3. replaceValues.sh Script

Create a `replaceValues.sh` script to replace template variables:

```bash
#!/bin/bash
# replaceValues.sh - Replace environment variables in template files

TEMPLATE_FILE=$1
OUTPUT_FILE=$2

if [ -z "$TEMPLATE_FILE" ] || [ -z "$OUTPUT_FILE" ]; then
  echo "Usage: $0 <template-file> <output-file>"
  exit 1
fi

# Use envsubst or manual replacement
envsubst < "$TEMPLATE_FILE" > "$OUTPUT_FILE"

echo "Processed $TEMPLATE_FILE -> $OUTPUT_FILE"
```

Make it executable:

```bash
chmod +x replaceValues.sh
```

## Creating Kubernetes Secrets

### 1. Azure Service Principal Credentials

```bash
# Create Azure credentials secret
kubectl create secret generic azure-sp-credentials \
  --from-literal=AZURE_CLIENT_ID="<your-client-id>" \
  --from-literal=AZURE_CLIENT_SECRET="<your-client-secret>" \
  --from-literal=AZURE_TENANT_ID="<your-tenant-id>" \
  --namespace default
```

### 2. Create ConfigMaps from Files

```bash
# Navigate to your workspace directory
cd /path/to/workspace

# Create certificates configmap
kubectl create configmap thingworx-certificates \
  --from-file=certificates/ \
  --namespace default

# Create helm charts configmap
kubectl create configmap thingworx-helm-ingress \
  --from-file=ingress-nginx/ \
  --namespace default

kubectl create configmap thingworx-helm-cert-manager \
  --from-file=cert-manager/ \
  --namespace default

kubectl create configmap thingworx-helm-monitoring \
  --from-file=kube-prometheus-stack/ \
  --from-file=loki-stack/ \
  --namespace default

# Create infrastructure configmap
kubectl create configmap thingworx-infrastructure \
  --from-file=infrastructure/ \
  --namespace default

# Create deployment templates configmap
kubectl create configmap thingworx-deployment \
  --from-file=deployment/ \
  --namespace default

# Create scripts configmap
kubectl create configmap thingworx-scripts \
  --from-file=replaceValues.sh \
  --from-file=common.yaml \
  --from-file=commonTemplate.env \
  --namespace default

chmod +x replaceValues.sh
kubectl create configmap thingworx-scripts \
  --from-file=replaceValues.sh \
  --from-file=common.yaml \
  --from-file=commonTemplate.env \
  --namespace default
```

### 3. Update values-thingworx.yaml with Volume Mounts

Edit `values-thingworx.yaml` and uncomment the volumes section:

```yaml
volumes:
  - name: certificates
    configMap:
      name: thingworx-certificates
  - name: ingress-nginx
    configMap:
      name: thingworx-helm-ingress
  - name: cert-manager
    configMap:
      name: thingworx-helm-cert-manager
  - name: monitoring
    configMap:
      name: thingworx-helm-monitoring
  - name: infrastructure
    configMap:
      name: thingworx-infrastructure
  - name: deployment
    configMap:
      name: thingworx-deployment
  - name: scripts
    configMap:
      name: thingworx-scripts
      defaultMode: 0755
  - name: workspace
    emptyDir: {}

volumeMounts:
  - name: certificates
    mountPath: /workspace/certificates
    readOnly: true
  - name: ingress-nginx
    mountPath: /workspace/ingress-nginx
    readOnly: true
  - name: cert-manager
    mountPath: /workspace/cert-manager
    readOnly: true
  - name: monitoring
    mountPath: /workspace/kube-prometheus-stack
    readOnly: true
  - name: infrastructure
    mountPath: /workspace/infrastructure
    readOnly: true
  - name: deployment
    mountPath: /workspace/deployment
    readOnly: true
  - name: scripts
    mountPath: /workspace
    readOnly: true
  - name: workspace
    mountPath: /workspace/work
```

## Deployment

### 1. Configure Environment Variables

Edit `values-thingworx.yaml` and set your environment:

```yaml
env:
  - name: ENV
    value: "d3"  # Change to your environment: d2, d3, q1, p1

  - name: REGCODE
    value: "521"  # 521 for global, 811 for china

  - name: REG
    value: "global"  # global or china
```

### 2. Configure Azure Authentication

**Option A: Using Service Principal (recommended for CI/CD)**

Uncomment and configure in `values-thingworx.yaml`:

```yaml
envFrom:
  - secretRef:
      name: azure-sp-credentials
```

**Option B: Using Azure Workload Identity (recommended for production)**

```yaml
serviceAccount:
  annotations:
    azure.workload.identity/client-id: "<your-managed-identity-client-id>"
```

### 3. Install the Helm Chart

```bash
# Install the deployment job
helm install thingworx-deploy ./shell-script-job \
  -f ./shell-script-job/values-thingworx.yaml \
  --namespace default

# Monitor the job
kubectl get jobs -w

# View logs
kubectl logs -f job/thingworx-deploy-shell-script-job

# Check pod status
kubectl get pods
```

### 4. Verify Deployment

```bash
# Check all namespaces created
kubectl get namespaces

# Check Thingworx pods
kubectl get pods -n <thingworx-namespace>

# Check ingress
kubectl get ingress -n ingress

# Check cert-manager
kubectl get certificates -n cert-manager

# Check storage classes
kubectl get storageclass

# Check Azure file shares (from Azure CLI)
az storage share list --account-name <storage-account-name>
```

## Troubleshooting

### Check Job Status

```bash
# Get job details
kubectl describe job thingworx-deploy-shell-script-job

# Get pod logs
POD_NAME=$(kubectl get pods --selector=job-name=thingworx-deploy-shell-script-job -o jsonpath='{.items[0].metadata.name}')
kubectl logs $POD_NAME

# Get previous logs if pod restarted
kubectl logs $POD_NAME --previous
```

### Common Issues

#### 1. Key Vault Access Denied

**Error**: `ERROR: (Forbidden) The user, group or application...`

**Solution**:
```bash
# Grant access to Key Vault
az keyvault set-policy \
  --name <keyvault-name> \
  --spn <service-principal-id> \
  --secret-permissions get list
```

#### 2. AKS Cluster Access Denied

**Error**: `error: You must be logged in to the server (Unauthorized)`

**Solution**:
```bash
# Get fresh credentials
az aks get-credentials \
  --resource-group <resource-group> \
  --name <aks-cluster> \
  --overwrite-existing
```

#### 3. Certificate Not Found

**Error**: `certificate does not exist, please create csr and request certificate`

**Solution**:
- Verify certificate files exist in the ConfigMap
- Check certificate naming convention
- Ensure certificate is in the correct directory structure

#### 4. Storage Account Not Found

**Error**: `The storage account <name> was not found`

**Solution**:
- Verify storage account exists in Azure
- Check service principal has `Storage Account Contributor` role
- Verify storage account name in Key Vault secret

#### 5. Helm Chart Not Found

**Error**: `Error: path "cert-manager/" not found`

**Solution**:
- Verify all Helm charts are included in ConfigMaps
- Check volume mounts are configured correctly
- Ensure working directory is `/workspace`

### Debug Mode

To run the job with extended debugging:

```yaml
# Add to values-thingworx.yaml under script section
set -x  # Already enabled
set -e  # Exit on error (add if needed)
```

### Cleanup

To remove the deployment job:

```bash
# Delete the job
helm uninstall thingworx-deploy

# Clean up completed jobs
kubectl delete job thingworx-deploy-shell-script-job

# Remove configmaps (if needed)
kubectl delete configmap thingworx-certificates
kubectl delete configmap thingworx-helm-ingress
kubectl delete configmap thingworx-infrastructure
```

## Support

For issues or questions:

1. Check job logs: `kubectl logs -f job/thingworx-deploy-shell-script-job`
2. Review Key Vault secrets configuration
3. Verify Azure permissions
4. Check AKS cluster health

## Reference

- **ENV values**: `d2`, `d3`, `q1`, `p1`
- **REGCODE values**:
  - `521` - Global production
  - `522` - Global secondary
  - `531` - Global dev (s1, t1)
  - `811` - China
- **Namespaces created**:
  - Thingworx application namespace (from `AKS-NS` secret)
  - `ingress`
  - `cert-manager`
  - `cert-manager-validation`
  - `monitoring`
